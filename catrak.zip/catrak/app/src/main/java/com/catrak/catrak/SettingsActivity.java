package com.catrak.catrak;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class SettingsActivity extends AppCompatActivity {

    // Declare EditText views
    private EditText editTextLatitude;
    private EditText editTextLongitude;
    private EditText editTextDistance;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        // Initialize EditText views
        editTextLatitude = findViewById(R.id.editText_latitude);
        editTextLongitude = findViewById(R.id.editText_longitude);
        editTextDistance = findViewById(R.id.editText_distance);

        Button buttonSave = findViewById(R.id.button_save);
        Button buttonExit = findViewById(R.id.button_exit);

        buttonSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveSettings();
            }
        });

        buttonExit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish(); // Finish the activity and return to the map view
            }
        });
    }

    private void saveSettings() {
        // Save user inputs
        String latitude = editTextLatitude.getText().toString();
        String longitude = editTextLongitude.getText().toString();
        String distance = editTextDistance.getText().toString();

        // Check if the user inputs are not empty
        if (!latitude.isEmpty() && !longitude.isEmpty() && !distance.isEmpty()) {
            // You can use SharedPreferences to save user settings
            SharedPreferences sharedPreferences = getSharedPreferences("settings", MODE_PRIVATE);
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putString("latitude", latitude);
            editor.putString("longitude", longitude);
            editor.putString("distance", distance);
            editor.apply();

            // Set the result to indicate that settings have been saved
            Intent resultIntent = new Intent();
            setResult(RESULT_OK, resultIntent);

            Toast.makeText(this, "Settings saved", Toast.LENGTH_SHORT).show();
        } else {
            // Show an error message if any of the inputs are empty
            Toast.makeText(this, "Please enter valid inputs for all fields", Toast.LENGTH_LONG).show();
        }
    }


}