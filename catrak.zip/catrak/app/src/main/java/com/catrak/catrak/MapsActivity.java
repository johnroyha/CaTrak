package com.catrak.catrak;

import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.fragment.app.FragmentActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Location;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.Circle;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.catrak.catrak.databinding.ActivityMapsBinding;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.Query;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.android.gms.maps.model.CircleOptions;

import androidx.annotation.NonNull;

import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.widget.Toast;

import androidx.core.app.NotificationCompat;



public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private ActivityMapsBinding binding;
    private Handler handler;
    private Runnable runnable;
    private Marker catrackMarker;
    private SharedPreferences sharedPreferences;
    private Marker baseStationMarker;
    private Circle circle;


    public double latitude;
    public double longitude;
    public double homeLatitude;
    public double homeLongitude;
    public double desiredRadius;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMapsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        handler = new Handler();
        createNotificationChannel();

        // Add a click listener for the settings button
        Button buttonSettings = findViewById(R.id.button_settings);
        buttonSettings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MapsActivity.this, SettingsActivity.class);
                startActivityForResult(intent, 1);
            }
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        // Check if the request code matches and the result is OK
        if (requestCode == 1 && resultCode == RESULT_OK) {
            updateBaseStationMarker();
        }
    }


    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        sharedPreferences = getSharedPreferences("settings", MODE_PRIVATE);
        LatLng cameraDefault = new LatLng(43.26358043123695, -79.91769857415801);
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(cameraDefault, 15));
        startRepeatingTask();



        DatabaseReference myRef = FirebaseDatabase.getInstance().getReference("UsersData/rknpPsqn5kUoCw10AEYSvlADp8B2/readings");
        Query latestReadingQuery = myRef.orderByKey().limitToLast(1);

        latestReadingQuery.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    for (DataSnapshot readingSnapshot : dataSnapshot.getChildren()) {
                        // Assuming 'data' is of type String
                        String latestData = readingSnapshot.child("data").getValue(String.class);

                        // Split the data by commas
                        String[] parts = latestData.split(",");
                        // Extract the latitude and longitude values, and trim any whitespace
                        String latitudeStr = parts[0].substring(1).trim(); // Remove the first character "c"
                        String longitudeStr = parts[1].trim();
                        // Convert the latitude and longitude strings to doubles
                        latitude = Double.parseDouble(latitudeStr);
                        longitude = Double.parseDouble(longitudeStr);
                        // Print the latitude and longitude values
                        Log.d("MainActivity", "Latest data: " + latestData);
                        Log.d("ParsedData", "Latitude: " + latitude + ", Longitude: " + longitude);

                        // Remove the old marker if it exists
                        if (catrackMarker != null) {
                            catrackMarker.remove();
                        }

                        // Add the new marker and move the camera
                        LatLng catrack = new LatLng(latitude, longitude);
                        catrackMarker = mMap.addMarker(new MarkerOptions().position(catrack).title("Catrack"));


                    }
                } else {
                    Log.d("MainActivity", "No data found");
                }
            }


            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.w("MainActivity", "Failed to read latest data.", databaseError.toException());
            }
        });
    }

    private void startRepeatingTask() {
        runnable = new Runnable() {
            @Override
            public void run() {
                // Call the calculateDistance method here and perform any necessary actions
                // 43.263556994309496, -79.91778440602498
                String latitudeStr2 = sharedPreferences.getString("latitude", "43.26358043123695");
                String longitudeStr2 = sharedPreferences.getString("longitude", "-79.91769857415801");
                String radiusStr = sharedPreferences.getString("distance", "100");

                homeLatitude = Double.parseDouble(latitudeStr2);
                homeLongitude = Double.parseDouble(longitudeStr2);
                desiredRadius = Double.parseDouble(radiusStr);

                float distance = calculateDistance(homeLatitude, homeLongitude, latitude, longitude);
                Log.d("MapsActivity", "Latitude: " + homeLatitude + " meters");
                Log.d("MapsActivity", "Longitude: " + homeLongitude + " meters");
                Log.d("MapsActivity", "Distance: " + distance + " meters");
                Log.d("MapsActivity", "Desired Radius: " + desiredRadius + " meters");
                if (distance > desiredRadius && baseStationMarker != null) {
                    Log.d("MapsActivity", "Testing");
                    Toast.makeText(getApplicationContext(), "Your pet has wandered too far!", Toast.LENGTH_LONG).show();
                    sendDistanceNotification();
                }

                handler.postDelayed(this, 10000); // Run every 10 seconds
            }
        };

        handler.post(runnable);
    }


    private void stopRepeatingTask() {
        handler.removeCallbacks(runnable);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        stopRepeatingTask(); // Stop the task when the activity is destroyed
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "DistanceChannel";
            String description = "Channel for distance notifications";
            int importance = NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel channel = new NotificationChannel("DISTANCE_CHANNEL_ID", name, importance);
            channel.setDescription(description);
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }
    }

    private void sendDistanceNotification() {
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, "DISTANCE_CHANNEL_ID")
                .setSmallIcon(R.drawable.ic_launcher_foreground) // Replace with your app's icon
                .setContentTitle("Distance Alert")
                .setContentText("Your pet has wandered too far!")
                .setPriority(NotificationCompat.PRIORITY_DEFAULT);

        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(this);
        notificationManager.notify(1, builder.build());
    }



    public float calculateDistance(double lat1, double lon1, double lat2, double lon2) {
        float[] results = new float[1];
        Location.distanceBetween(lat1, lon1, lat2, lon2, results);
        return results[0];
    }

    private void updateBaseStationMarker() {
        // Get the updated settings
        sharedPreferences = getSharedPreferences("settings", MODE_PRIVATE);
        String latitudeStr2 = sharedPreferences.getString("latitude", "43.26358043123695");
        String longitudeStr2 = sharedPreferences.getString("longitude", "-79.91769857415801");

        // Update the homeLatitude and homeLongitude
        homeLatitude = Double.parseDouble(latitudeStr2);
        homeLongitude = Double.parseDouble(longitudeStr2);

        // Remove the existing base station marker if it exists
        if (baseStationMarker != null) {
            baseStationMarker.remove();
        }

        // Add the new base station marker
        LatLng baseStation = new LatLng(homeLatitude, homeLongitude);
        MarkerOptions customMarker = new MarkerOptions()
                .position(baseStation)
                .title("Base Station")
                .snippet("Catrak");

        baseStationMarker = mMap.addMarker(customMarker);
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(baseStation, 18));

        // Remove the existing circle if it exists
        if (circle != null) {
            circle.remove();
        }

        // Add a circle (ring) centered at catrack with a 100-meter radius
        CircleOptions circleOptions = new CircleOptions()
                .center(baseStation)
                .radius(desiredRadius) // Radius in meters
                .strokeColor(Color.BLUE) // Optional: set the stroke color
                .strokeWidth(5); // Optional: set the stroke width

        circle = mMap.addCircle(circleOptions);
    }




}